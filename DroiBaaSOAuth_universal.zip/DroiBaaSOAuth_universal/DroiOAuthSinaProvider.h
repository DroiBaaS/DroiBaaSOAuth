//
//  DroiOAuthSinaProvider.h
//  DroiOAuthSinaProvider
//
//  Created by Skyer Tai on 2016/8/9.
//  Copyright © 2016年 droi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DroiCoreSDK/DroiOAuthProvider.h"

@interface DroiOAuthSinaProvider : DroiOAuthProvider
+(BOOL) initialize;
@end
